﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;
namespace DonacionSangre
{
    public partial class Solicitud : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (DropDownList2.Items.Count == 0)
            {
                ConexionBD objetoConexion = new ConexionBD();
                OdbcConnection con = objetoConexion.con;
                String querySangre = "select cSangre, tipodeSangre from tipoDeSangre";
                OdbcCommand comando = new OdbcCommand(querySangre, con);
                OdbcDataReader lector = comando.ExecuteReader();
                if (lector.HasRows == true)
                {
                    DropDownList2.DataSource = lector;
                    DropDownList2.DataValueField = "cSangre";//nunca se ve, es una referencia
                    DropDownList2.DataTextField = "tipodeSangre";//lo ve el usuario
                    DropDownList2.DataBind();//ligar el lector al dropdown
                    lector.Close();
                }
            }

            if (DropDownList1.Items.Count == 0)
            {
                ConexionBD objetoConexion = new ConexionBD();
                OdbcConnection con = objetoConexion.con;
                int ciudad = (Int32)Session["ciudad"];
                String query = "select cHospital,nombreHospital,Hospital.cCiudad from Hospital where cCiudad=?";
                OdbcCommand comando = new OdbcCommand(query, con);
                comando.Parameters.AddWithValue("cCiudad", ciudad);
                OdbcDataReader lector = comando.ExecuteReader();
                if (lector.HasRows == true)
                {
                    DropDownList1.DataSource = lector;
                    DropDownList1.DataValueField = "cHospital";//nunca se ve, es una referencia
                    DropDownList1.DataTextField = "nombreHospital";//lo ve el usuario
                    DropDownList1.DataBind();//ligar el lector al dropdown
                    lector.Close();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int cSolicitud = 600;
            ConexionBD objetoConexion = new ConexionBD();
            OdbcConnection con = objetoConexion.con;
            String queryClave = "select MAX(cSolicitud) from Solicitud";
            OdbcCommand comando = new OdbcCommand(queryClave, con);
            OdbcDataReader lector = comando.ExecuteReader();
            lector.Read();
            if (lector.HasRows == true)
            {
                try
                {
                    cSolicitud = lector.GetInt32(0);
                    cSolicitud++;
                    lector.Close();
                }
                catch (Exception exp)
                {
                    cSolicitud = 601;
                    lector.Close();
                }
            }
            String insertCita = "insert into Solicitud values (?,?,?,?)";
            comando = new OdbcCommand(insertCita, con);
            comando.Parameters.AddWithValue("cSolicitud", cSolicitud);
            comando.Parameters.AddWithValue("cHospital", DropDownList1.SelectedValue);
            comando.Parameters.AddWithValue("cSangre", DropDownList2.SelectedValue);
            comando.Parameters.AddWithValue("numeroDonadores", TextBox1.Text.ToString());//NO ES STRING!!! ES INT PERO NO ENCUENTRO EL COMANDO
            int res = comando.ExecuteNonQuery();
            if (res != 0)
            {
                Label1.Text = "Solicitud enviada con éxito";
            }
        }
    }

}