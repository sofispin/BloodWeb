﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;
namespace DonacionSangre
{
    public partial class Registro : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ConexionBD objetoConexion = new ConexionBD();
            OdbcConnection con = objetoConexion.con;
            String queryTipoSangre = "select cSangre, tipodeSangre from tipoDeSangre";
            String queryCiudad = "select cCiudad, nombre from ciudad";
            OdbcCommand comando = new OdbcCommand(queryTipoSangre, con);
            OdbcDataReader lector = comando.ExecuteReader();
            if (DropDownList1.Items.Count == 0)
            {
                if (lector.HasRows == true)
                {
                    DropDownList1.DataSource = lector;
                    DropDownList1.DataValueField = "cSangre";//nunca se ve, es una referencia
                    DropDownList1.DataTextField = "tipoDeSangre";//lo ve el usuario
                    DropDownList1.DataBind();//ligar el lector al dropdown
                    lector.Close();
                }
            }
            lector.Close();
            comando = new OdbcCommand(queryCiudad, con);
            lector = comando.ExecuteReader();
            if (DropDownList2.Items.Count == 0)
            {
                if (lector.HasRows == true)
                {
                    DropDownList2.DataSource = lector;
                    DropDownList2.DataValueField = "cCiudad";//nunca se ve, es una referencia
                    DropDownList2.DataTextField = "nombre";//lo ve el usuario
                    DropDownList2.DataBind();//ligar el lector al dropdown
                    lector.Close();

                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String consulta = "select correo from Usuario where correo =?";
            ConexionBD objetoConexion = new ConexionBD();
            OdbcConnection con = objetoConexion.con;
            String correo = TextBox2.Text;
            OdbcCommand comando = new OdbcCommand(consulta, con);
            comando.Parameters.AddWithValue("correo", correo);
            OdbcDataReader lector = comando.ExecuteReader();
            if (lector.HasRows == true)
            {
                Label1.Text = "Correo ya registrado";
                lector.Close();
            }
            else
            {
                lector.Close();
                if (TextBox3.Text.ToString().Equals(TextBox4.Text.ToString()))
                {
                    if (TextBox5.Text.Length == 10)
                    {
                        String insertUsuario = "insert into Usuario values(?,?,?,?,?,?,?)";//correo,pass,tel,nom,tipoSan,ciudad,tipoUsuario
                        //Crear historailes
                        //String insertHistorialD = "";
                        //String insertHistorialP = "";
                        comando = new OdbcCommand(insertUsuario, con);
                        comando.Parameters.AddWithValue("correo", correo);
                        comando.Parameters.AddWithValue("contraseña", TextBox3.Text.ToString());
                        comando.Parameters.AddWithValue("telefono", TextBox5.Text.ToString());
                        comando.Parameters.AddWithValue("nombre", TextBox1.Text.ToString());
                        comando.Parameters.AddWithValue("cSangre", DropDownList1.SelectedValue);
                        comando.Parameters.AddWithValue("cCiudad", DropDownList2.SelectedValue);
                        comando.Parameters.AddWithValue("tipoUsuario", 1);
                        comando.ExecuteNonQuery();
                        Label1.Text = "Registro exitoso";
                    }
                    else
                    {
                        Label5.Text = "Verifica tu teléfono";
                        Label3.Text = "(*)";

                    }

                }
                else
                {
                    Label1.Text = "Verifica tu contraseña";
                    Label4.Text = "(*)";
                    Label2.Text = "(*)";
                }
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}