﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;

namespace DonacionSangre
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session.Clear();
            Session.Timeout = 10;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            ConexionBD objetoConexion = new ConexionBD();
            OdbcConnection con = objetoConexion.con;
            String consulta =
                "select correo,nombre, tipoUsuario,cCiudad from usuario where correo=? and contraseña=?";
            OdbcCommand comando = new OdbcCommand(consulta, con);
            comando.Parameters.AddWithValue("correo", TextBox1.Text);
            comando.Parameters.AddWithValue("contraseña", TextBox2.Text);

            OdbcDataReader lector = comando.ExecuteReader();
            if (lector.HasRows == true)
            {
                lector.Read();
                String correo = lector.GetString(0);
                String nombre = lector.GetString(1);
                int tipousuario = lector.GetInt32(2);
                int ciudad = lector.GetInt32(3);

                Session.Add("correo", correo);
                Session.Add("nombre", nombre);
                Session.Add("ciudad", ciudad);
                
                con.Close();
                if (tipousuario.Equals(0))
                {
                    Response.Redirect("Admin.aspx");
                }
                else
                {
                    Response.Redirect("Inicio.aspx");
                }

                
            }
            else
            {
                con.Close();
                Response.Write("Credenciales incorrectas");
                Session.Abandon();
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Registro.aspx");
        }
    }
}