﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;

namespace DonacionSangre
{
    public partial class Cita : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (DropDownList1.Items.Count == 0)
            {
                DropDownList1.Items.Add("1");
                DropDownList1.Items.Add("2");
                DropDownList1.Items.Add("3");
                DropDownList1.Items.Add("4");
                DropDownList1.Items.Add("5");
                DropDownList1.Items.Add("6");
                DropDownList1.Items.Add("7");
                DropDownList1.Items.Add("8");
                DropDownList1.Items.Add("9");
                DropDownList1.Items.Add("10");
                DropDownList1.Items.Add("11");
                DropDownList1.Items.Add("12");
                DropDownList1.Items.Add("13");
                DropDownList1.Items.Add("14");
                DropDownList1.Items.Add("15");
                DropDownList1.Items.Add("16");
                DropDownList1.Items.Add("17");
                DropDownList1.Items.Add("18");
                DropDownList1.Items.Add("19");
                DropDownList1.Items.Add("20");
                DropDownList1.Items.Add("21");
                DropDownList1.Items.Add("22");
                DropDownList1.Items.Add("23");
                DropDownList1.Items.Add("24");
                DropDownList1.Items.Add("25");
                DropDownList1.Items.Add("26");
                DropDownList1.Items.Add("27");
                DropDownList1.Items.Add("28");
                DropDownList1.Items.Add("29");
                DropDownList1.Items.Add("30");
                DropDownList1.Items.Add("31");
            }

            if (DropDownList2.Items.Count == 0)
            {
                ConexionBD objetoConexion = new ConexionBD();
                OdbcConnection con = objetoConexion.con;
                String query = "select cMes,nombreMes from Mes";
                OdbcCommand comando = new OdbcCommand(query, con);
                OdbcDataReader lector = comando.ExecuteReader();
                if (lector.HasRows == true)
                {
                    DropDownList2.DataSource = lector;
                    DropDownList2.DataValueField = "cMes";//nunca se ve, es una referencia
                    DropDownList2.DataTextField = "nombreMes";//lo ve el usuario
                    DropDownList2.DataBind();//ligar el lector al dropdown
                    lector.Close();
                }
                
            }
            if (DropDownList3.Items.Count == 0)
            {
                DropDownList3.Items.Add("2019");
                DropDownList3.Items.Add("2020");
            }
            if (DropDownList4.Items.Count == 0)
            {
                ConexionBD objetoConexion = new ConexionBD();
                OdbcConnection con = objetoConexion.con;
                int ciudad = (Int32)Session["ciudad"];
                String query = "select cHospital,nombreHospital,Hospital.cCiudad from Hospital where cCiudad=?";
                OdbcCommand comando = new OdbcCommand(query, con);
                comando.Parameters.AddWithValue("cCiudad", ciudad);
                OdbcDataReader lector = comando.ExecuteReader();
                if (lector.HasRows == true)
                {
                    DropDownList4.DataSource = lector;
                    DropDownList4.DataValueField = "cHospital";//nunca se ve, es una referencia
                    DropDownList4.DataTextField = "nombreHospital";//lo ve el usuario
                    DropDownList4.DataBind();//ligar el lector al dropdown
                    lector.Close();
                }

            }
            RadioButton1.Text = "Sí cumplo con los requisitos";
            /*if (RadioButtonLis1.Items.Count == 0)
            {
                RadioButtonList1.Items.Add("Sí");
                RadioButtonList1.Items.Add("No");
            }*/
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            if (RadioButton1.Checked)
            {
                int cCita=0;
                ConexionBD objetoConexion = new ConexionBD();
                OdbcConnection con = objetoConexion.con;
                String queryClave = "select MAX(cCita) from Cita";
                OdbcCommand comando = new OdbcCommand(queryClave,con);
                OdbcDataReader lector = comando.ExecuteReader();
                lector.Read();
                if (lector.HasRows == true)
                {
                    try
                    {
                        cCita=lector.GetInt32(0);
                        cCita++;
                        lector.Close();
                    }
                    catch (Exception exp)
                    {
                        cCita = 1;
                        lector.Close();
                    }
                }
                String dia, mes, anio, fecha;
                dia = DropDownList1.SelectedItem.ToString();
                mes = DropDownList2.SelectedValue.ToString();
                anio = DropDownList3.SelectedItem.ToString();
                fecha = anio + "-" + mes + "-" + dia;
                String insertCita = "insert into Cita values (?,?,?)";
                comando = new OdbcCommand(insertCita, con);
                comando.Parameters.AddWithValue("cCita",cCita);
                comando.Parameters.AddWithValue("fecha",fecha);
                comando.Parameters.AddWithValue("correo",Session["correo"]);
                int res=comando.ExecuteNonQuery();
                if (res != 0)
                {
                    Label1.Text = "Cita agendada con éxito";
                }
            }
            else
            {
                Label1.Text = "Lo sentimos, pero no puedes donar si no cumples con los requisitos";
            }
        }
    }
}