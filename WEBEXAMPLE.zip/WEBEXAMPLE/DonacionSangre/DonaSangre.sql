use DonarSangre

--Agregar clave historiales a tabla usuario
create table ciudad (cCiudad int primary key, nombre varchar (100))
create table tipoDeSangre (cSangre int primary key, tipoDeSangre varchar (100))
create table Usuario (correo varchar(100) primary key, contrase�a varchar(50), telefono varchar(100), nombre varchar(200), cSangre int references tipoDeSangre, cCiudad int references Ciudad, tipoUsuario int)
create table Hospital(cHospital int primary key, nombreHospital varchar(200), direccionHosp varchar (250), cCiudad int references Ciudad)
create table Cita(cCita int primary key, fechaCita datetime, correo varchar(100) references Usuario)
create table Donacion(cDonacion int primary key, fechaDon datetime, cHospital int references Hospital, cCita int references cita)
create table historialP (folioHistorial int primary key, fecha datetime)
create table atiende (folioHistorial int references historialP, correo varchar(100) references Usuario, cHospital int references Hospital, primary key (folioHistorial, correo))
create table HistorialD (folioHD int primary key, fecha datetime)
create table haceCita (folioHD int references historialD, correo varchar (100) references Usuario, cCita int references cita, primary key (cCita, correo))
create table Solicitud(cSolicitud int primary key, cHospital int references Hospital, cSangre int references tipoDeSangre, numeroDonadores int)

insert into ciudad values(100, 'CDMX')
insert into ciudad values(200, 'MTY')
insert into ciudad values(300, 'GDL')
insert into tipoDeSangre values(10, 'A+')
insert into tipoDeSangre values(11, 'A-')
insert into tipoDeSangre values(20, 'B+')
insert into tipoDeSangre values(21, 'B-')
insert into tipoDeSangre values(30, 'AB+')
insert into tipoDeSangre values(31, 'AB-')
insert into tipoDeSangre values(40, 'O+')
insert into tipoDeSangre values(41, 'O-')
insert into Usuario values('jorge@hotmail.com', 'jorgito', '55628364', 'Jorge', 20, 300, 1)
insert into Usuario values('maria@hotmail.com', 'mary', '55235674', 'Maria', 10, 100, 1)
insert into Usuario values('liliana@hotmail.com', 'lili', '55953637', 'Liliana', 41, 200, 1)
insert into Usuario values('admin@hotmail.com', 'admin', '55936292', 'Administrador', 31, 100, 0)
select correo from Usuario where correo='raul@hotmail.com'

create table Mes (cMes int primary key, nombreMes varchar(20))
insert into Mes values(1, 'Enero')
insert into Mes values(2, 'Febrero')
insert into Mes values(3, 'Marzo')
insert into Mes values(4, 'Abril')
insert into Mes values(5, 'Mayo')
insert into Mes values(6, 'Junio')
insert into Mes values(7, 'Julio')
insert into Mes values(8, 'Agosto')
insert into Mes values(9, 'Septiembre')
insert into Mes values(10, 'Octubre')
insert into Mes values(11, 'Noviembre')
insert into Mes values(12, 'Diciembre')

select cMes,nombreMes from Mes
select * from Cita
select MAX(cCita) from Cita
delete from Cita where cCita=1

insert into Hospital values (0001, 'Hospital �ngeles', 'Calle del �ngel 1', 100)
insert into Hospital values (0002, 'Hospital ABC', 'Calle del vocabulario 2', 200)
insert into Hospital values (0003, 'Hospital Espa�ol', 'Calle de los pinos 10', 300)

insert into Hospital values (0004, 'Hospital Ingl�s', 'Calle Inglesa 4', 100)

select cHospital,nombreHospital, Hospital.cCiudad from Hospital where cCiudad=300
insert into Cita values (1,'2019-14-3','jorge@hotmail.com')
--insert into HistorialD();

select cCiudad, nombre from ciudad